// Assignment 1:
// Work with datatypes in TS such as boolean, any, array of strings, heterogenous arrays with examples.
// Print the output to the console in VS Code. 


var a:boolean = true
var b:any = "muskan"
var c:string[] = ['muskan','adil','atif']

console.log(a)
console.log(b)
console.log(c)

//hetrogenous array
var rows: number = 3;
var cols: number = 3;
var arr: string[][] = [];
for (let i = 0; i < rows; i++) {
   arr[i] = [];
   for (let j = 0; j < cols; j++) {
      arr[i][j] = String.fromCharCode(65 + i) + (j + 1);
   }
}
console.log(arr);


// Assignment 2:
// Work with various Popups available in TypeScript such as alert, confirm, prompt.
// Print the output to the console in VS Code.

function getUserDetails(){
    alert("hi")   
}

getUserDetails()

//confirm
confirm("Confirm demo, Press a button!");


//prompt
function myFunction() {
    let person = prompt("Please enter your name", "Harry Potter");
    if (person != null) {
      document.getElementById("demo").innerHTML =
      "Hello " + person + "! How are you today?";
    }
  }