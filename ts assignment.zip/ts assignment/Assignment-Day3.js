// Assignment 1:
// Work with datatypes in TS such as boolean, any, array of strings, heterogenous arrays with examples.
// Print the output to the console in VS Code. 
var a = true;
var b = "muskan";
var c = ['muskan', 'adil', 'atif'];
console.log(a);
console.log(b);
console.log(c);
//hetrogenous array
var rows = 3;
var cols = 3;
var arr = [];
for (var i = 0; i < rows; i++) {
    arr[i] = [];
    for (var j = 0; j < cols; j++) {
        arr[i][j] = String.fromCharCode(65 + i) + (j + 1);
    }
}
console.log(arr);
// Assignment 2:
// Work with various Popups available in TypeScript such as alert, confirm, prompt.
// Print the output to the console in VS Code.
function getUserDetails() {
    alert("hi");
}
getUserDetails();
//confirm
confirm("Confirm demo, Press a button!");
//prompt
function myFunction() {
    var person = prompt("Please enter your name", "Harry Potter");
    if (person != null) {
        document.getElementById("demo").innerHTML =
            "Hello " + person + "! How are you today?";
    }
}
